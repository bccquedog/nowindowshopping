function $(id) {
  return document.getElementById(id);
}

function setStatus(text, isError = false) {
  const el = $("statusText");
  el.textContent = text;
  el.style.color = isError ? "#b91c1c" : "#065f46";
}

function splitLines(input) {
  return input
    .split(/\n/g)
    .map((line) => line.trim())
    .filter(Boolean);
}

function splitKeywords(input) {
  return input
    .split(/\n|,/g)
    .map((line) => line.trim())
    .filter(Boolean);
}

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

async function loadSettings() {
  const response = await send("PM_GET_SETTINGS");
  const settings = response.settings || {};

  const rules = (settings.autoStartRules || []).map((rule) => rule.pattern).join("\n");
  $("autoStartRules").value = rules;
  $("predefinedUrls").value = (settings.predefinedUrls || []).join("\n");
  $("defaultKeyword").value = settings.defaultTabConfig?.monitor?.keyword || "";
  $("defaultNegativeKeywords").value = (settings.defaultTabConfig?.monitor?.negativeKeywords || []).join("\n");
  $("remoteEnabled").checked = Boolean(settings.remoteNotifications?.enabled);
  $("remoteWebhookUrl").value = settings.remoteNotifications?.webhookUrl || "";
  $("remoteAuthToken").value = settings.remoteNotifications?.authToken || "";
  $("remoteCooldownSec").value = toNumber(settings.remoteNotifications?.cooldownSec, 60);
  $("soundEnabled").checked = Boolean(settings.soundNotifications?.enabled);
  $("soundVolume").value = toNumber(settings.soundNotifications?.volume, 0.6);
  $("soundRepeatCount").value = toNumber(settings.soundNotifications?.repeatCount, 2);
  $("soundFrequencyHz").value = toNumber(settings.soundNotifications?.frequencyHz, 880);
}

async function saveSettings() {
  const existing = await send("PM_GET_SETTINGS");
  const settings = existing.settings || {};

  const autoStartRules = splitLines($("autoStartRules").value).map((pattern) => ({
    enabled: true,
    pattern
  }));

  const predefinedUrls = splitLines($("predefinedUrls").value);
  const defaultKeyword = $("defaultKeyword").value.trim();
  const defaultNegativeKeywords = splitKeywords($("defaultNegativeKeywords").value);

  settings.autoStartRules = autoStartRules;
  settings.predefinedUrls = predefinedUrls;
  settings.defaultTabConfig = settings.defaultTabConfig || {};
  settings.defaultTabConfig.monitor = settings.defaultTabConfig.monitor || {};
  settings.defaultTabConfig.monitor.keyword = defaultKeyword;
  settings.defaultTabConfig.monitor.negativeKeywords = defaultNegativeKeywords;
  settings.remoteNotifications = settings.remoteNotifications || {};
  settings.remoteNotifications.enabled = $("remoteEnabled").checked;
  settings.remoteNotifications.webhookUrl = $("remoteWebhookUrl").value.trim();
  settings.remoteNotifications.authToken = $("remoteAuthToken").value.trim();
  settings.remoteNotifications.cooldownSec = toNumber($("remoteCooldownSec").value, 60);
  settings.soundNotifications = settings.soundNotifications || {};
  settings.soundNotifications.enabled = $("soundEnabled").checked;
  settings.soundNotifications.volume = Math.max(0, Math.min(1, toNumber($("soundVolume").value, 0.6)));
  settings.soundNotifications.repeatCount = Math.max(1, Math.min(5, toNumber($("soundRepeatCount").value, 2)));
  settings.soundNotifications.frequencyHz = Math.max(220, Math.min(2200, toNumber($("soundFrequencyHz").value, 880)));

  await send("PM_SAVE_SETTINGS", { settings });
  setStatus("Options saved");
}

document.getElementById("saveOptionsBtn").addEventListener("click", () => {
  saveSettings().catch((err) => setStatus(String(err?.message || err), true));
});

document.getElementById("testSoundBtn").addEventListener("click", async () => {
  try {
    await saveSettings();
    const response = await send("PM_TEST_SOUND");
    if (response?.ok) {
      setStatus("Test sound sent");
    } else {
      setStatus("Unable to play test sound on active tab", true);
    }
  } catch (err) {
    setStatus(String(err?.message || err), true);
  }
});

loadSettings().catch((err) => setStatus(String(err?.message || err), true));
