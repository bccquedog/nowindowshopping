const OVERLAY_ID = "pm-pro-visual-timer";
let timerIntervalId = null;
let interactionHooksEnabled = false;
let alertAudioCtx = null;
let lastAssistDebug = [];

function hashString(input) {
  let hash = 0;
  for (let i = 0; i < input.length; i += 1) {
    hash = (hash << 5) - hash + input.charCodeAt(i);
    hash |= 0;
  }
  return String(hash);
}

function getSourceText(sourceMode) {
  if (sourceMode === "html") {
    return document.documentElement?.outerHTML || "";
  }
  return document.body?.innerText || "";
}

function isElementClickable(el) {
  if (!(el instanceof HTMLElement)) {
    return false;
  }
  if (el.hasAttribute("disabled")) {
    return false;
  }
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden" || style.pointerEvents === "none") {
    return false;
  }
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function isElementEnabled(el) {
  if (!(el instanceof HTMLElement)) {
    return false;
  }
  if (el.hasAttribute("disabled")) {
    return false;
  }
  if ("disabled" in el && el.disabled) {
    return false;
  }
  if ("readOnly" in el && el.readOnly) {
    return false;
  }
  if (el.getAttribute("aria-disabled") === "true") {
    return false;
  }
  const classes = String(el.className || "").toLowerCase();
  if (classes.includes("disabled") || classes.includes("is-disabled")) {
    return false;
  }
  return true;
}

function getElementText(el) {
  if (!(el instanceof HTMLElement)) {
    return "";
  }
  return (el.innerText || el.textContent || "").trim().toLowerCase();
}

function normalizeSizeToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/[^a-z0-9]/g, "");
}

function clickElement(el) {
  if (!(el instanceof HTMLElement)) {
    return false;
  }
  el.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
  try {
    el.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true }));
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
  } catch {
    // Ignore pointer event constructor issues in older contexts.
  }
  el.click();
  if (el instanceof HTMLInputElement && el.type === "submit") {
    const form = el.closest("form");
    if (form && typeof form.requestSubmit === "function") {
      form.requestSubmit();
    }
  }
  return true;
}

function findByText(selector, textRegex) {
  const nodes = Array.from(document.querySelectorAll(selector));
  for (const node of nodes) {
    if (!(node instanceof HTMLElement) || !isElementClickable(node)) {
      continue;
    }
    if (textRegex.test(getElementText(node))) {
      return node;
    }
  }
  return null;
}

function tryClickBySelectors(selectors = []) {
  for (const selector of selectors) {
    const nodes = Array.from(document.querySelectorAll(selector));
    const target = nodes.find((el) => isElementClickable(el)) || nodes[0];
    if (target instanceof HTMLElement && clickElement(target)) {
      return true;
    }
  }
  return false;
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function createDebugRecorder(enabled = false) {
  const lines = [];
  return {
    enabled,
    log(message) {
      if (!enabled) {
        return;
      }
      const line = `${new Date().toISOString().slice(11, 19)} ${message}`;
      lines.push(line);
      try {
        console.debug("[Page Monitor Pro]", line);
      } catch {
        // Ignore console failures.
      }
    },
    snapshot() {
      return lines.slice();
    }
  };
}

function saveAssistDebug(lines) {
  lastAssistDebug = Array.isArray(lines) ? lines.slice() : [];
}

function collectSizeSelectElements() {
  return Array.from(document.querySelectorAll("select")).filter((el) => {
    if (!(el instanceof HTMLSelectElement) || el.disabled) {
      return false;
    }
    const signature = `${el.name || ""} ${el.id || ""} ${el.className || ""}`.toLowerCase();
    return signature.includes("size");
  });
}

function selectOptionInSelect(selectEl, preferredSizes = []) {
  if (!(selectEl instanceof HTMLSelectElement)) {
    return false;
  }
  const options = Array.from(selectEl.options).filter((opt) => {
    if (!(opt instanceof HTMLOptionElement) || opt.disabled) {
      return false;
    }
    const text = String(opt.textContent || "").trim().toLowerCase();
    return Boolean(opt.value) && !text.includes("select") && !text.includes("choose");
  });
  if (!options.length) {
    return false;
  }

  const normalizedTargets = preferredSizes.map((item) => normalizeSizeToken(item)).filter(Boolean);
  let targetOption = null;
  if (normalizedTargets.length) {
    targetOption = options.find((opt) => {
      const text = normalizeSizeToken(opt.textContent || "");
      const value = normalizeSizeToken(opt.value || "");
      return normalizedTargets.some((target) => text.includes(target) || value.includes(target));
    });
  }
  if (!targetOption) {
    [targetOption] = options;
  }
  if (!targetOption) {
    return false;
  }

  selectEl.value = targetOption.value;
  selectEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
  selectEl.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
  selectEl.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true }));
  return true;
}

function hasSelectedSize(selectEl) {
  if (!(selectEl instanceof HTMLSelectElement)) {
    return false;
  }
  const selectedText = String(
    selectEl.options[selectEl.selectedIndex]?.textContent || selectEl.value || ""
  ).toLowerCase();
  return Boolean(selectEl.value) && !selectedText.includes("select") && !selectedText.includes("choose");
}

function getSelectedSizeSummary() {
  return collectSizeSelectElements()
    .map((selectEl) => String(selectEl.value || selectEl.options[selectEl.selectedIndex]?.textContent || "").trim())
    .filter(Boolean)
    .join(", ");
}

function ensurePreferredSizeSelected(preferredSizes = []) {
  const sizeSelects = collectSizeSelectElements();
  let changed = false;
  for (const sizeSelect of sizeSelects) {
    if (!hasSelectedSize(sizeSelect) || preferredSizes.length) {
      changed = selectOptionInSelect(sizeSelect, preferredSizes) || changed;
    }
  }
  return changed || sizeSelects.some((selectEl) => hasSelectedSize(selectEl));
}

function getRelevantRadioGroups() {
  const radios = Array.from(document.querySelectorAll("input[type='radio']")).filter(
    (input) => input instanceof HTMLInputElement && !input.disabled
  );
  const relevant = radios.filter((input) => {
    const signature = `${input.name || ""} ${input.value || ""} ${
      input.getAttribute("aria-label") || ""
    } ${input.closest("label")?.innerText || ""} ${input.parentElement?.innerText || ""}`.toLowerCase();
    return /sth|sts|ship|store|pickup|home|delivery/.test(signature);
  });
  const groups = new Map();
  for (const radio of relevant) {
    const key = radio.name || "__ungrouped__";
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key).push(radio);
  }
  return groups;
}

function getRadioGroupSummary() {
  return Array.from(getRelevantRadioGroups().values())
    .flat()
    .map((radio) => `${radio.name || "radio"}:${radio.value || radio.id || "unknown"}=${radio.checked ? "checked" : "off"}`)
    .join(", ");
}

function findPreferredSizeElement(preferredSizes = []) {
  const normalizedTargets = preferredSizes
    .map((item) => normalizeSizeToken(item))
    .filter(Boolean);
  if (!normalizedTargets.length) {
    return null;
  }

  const candidates = Array.from(
    document.querySelectorAll(
      ".product-size button, .size-selector button, [data-option*='size' i] button, [class*='size' i] button, [class*='size' i] [role='button'], button, [role='button'], label"
    )
  );
  for (const candidate of candidates) {
    if (!(candidate instanceof HTMLElement) || !isElementClickable(candidate)) {
      continue;
    }
    const text = normalizeSizeToken(getElementText(candidate));
    if (!text) {
      continue;
    }
    if (normalizedTargets.some((target) => text.includes(target))) {
      return candidate;
    }
  }
  return null;
}

function findAddToCartElement() {
  const strictSelectors = [
    "button[aria-label*='add to cart' i]",
    "button[title*='add to cart' i]",
    "button[name*='add' i][name*='cart' i]",
    "button[id*='add' i][id*='cart' i]",
    "input[type='submit'][value*='add to cart' i]",
    "input[type='button'][value*='add to cart' i]",
    "[data-testid*='add-to-cart' i]",
    "[data-test*='add-to-cart' i]"
  ];
  for (const selector of strictSelectors) {
    const nodes = Array.from(document.querySelectorAll(selector));
    const target = nodes.find((el) => isElementClickable(el) && isElementEnabled(el));
    if (target instanceof HTMLElement) {
      return target;
    }
  }

  for (const selector of strictSelectors) {
    const nodes = Array.from(document.querySelectorAll(selector));
    const target = nodes.find((el) => isElementClickable(el));
    if (target instanceof HTMLElement) {
      forceEnableControl(target);
      return target;
    }
  }

  const candidate = findByText(
    "button, input[type='submit'], input[type='button'], [role='button']",
    /add\s*to\s*cart|add\s*to\s*bag/i
  );
  if (candidate) {
    const text = getElementText(candidate);
    if (!/wishlist|registry/.test(text)) {
      forceEnableControl(candidate);
      return candidate;
    }
  }
  return null;
}

function findAddToCartControl() {
  const selectors = [
    "button[aria-label*='add to cart' i]",
    "button[title*='add to cart' i]",
    "button[name*='add' i][name*='cart' i]",
    "button[id*='add' i][id*='cart' i]",
    "input[type='submit'][value*='add to cart' i]",
    "input[type='button'][value*='add to cart' i]",
    "[data-testid*='add-to-cart' i]",
    "[data-test*='add-to-cart' i]"
  ];
  for (const selector of selectors) {
    const target = document.querySelector(selector);
    if (target instanceof HTMLElement) {
      return target;
    }
  }
  return (
    findByText("button, input[type='submit'], [role='button']", /add\s*to\s*cart|add\s*to\s*bag/i) || null
  );
}

function describeAddToCartControl(control) {
  if (!(control instanceof HTMLElement)) {
    return "missing";
  }
  const tag = control.tagName.toLowerCase();
  const type = control.getAttribute("type") || "";
  const disabled = control.hasAttribute("disabled");
  const readOnly = control.hasAttribute("readonly");
  const ariaDisabled = control.getAttribute("aria-disabled") || "";
  return `${tag}${type ? `[type=${type}]` : ""} disabled=${disabled} readonly=${readOnly} ariaDisabled=${ariaDisabled || "false"}`;
}

function forceEnableControl(control) {
  if (!(control instanceof HTMLElement)) {
    return false;
  }
  let changed = false;
  if ("readOnly" in control && control.readOnly) {
    control.readOnly = false;
    changed = true;
  }
  if (control.hasAttribute("readonly")) {
    control.removeAttribute("readonly");
    changed = true;
  }
  if ("disabled" in control && control.disabled) {
    control.disabled = false;
    changed = true;
  }
  if (control.hasAttribute("disabled")) {
    control.removeAttribute("disabled");
    changed = true;
  }
  if (control.getAttribute("aria-disabled") === "true") {
    control.setAttribute("aria-disabled", "false");
    changed = true;
  }
  const classes = String(control.className || "");
  if (/\bdisabled\b|\bis-disabled\b/.test(classes)) {
    control.className = classes.replace(/\bdisabled\b/g, "").replace(/\bis-disabled\b/g, "").trim();
    changed = true;
  }
  return changed;
}

function forceSubmitFromAddControl(addControl) {
  if (!(addControl instanceof HTMLElement)) {
    return false;
  }
  const form = addControl.closest("form");
  if (!form) {
    return false;
  }
  try {
    if (typeof form.requestSubmit === "function") {
      form.requestSubmit();
    } else {
      form.submit();
    }
    return true;
  } catch {
    return false;
  }
}

function extractNexSkuId() {
  const scripts = document.querySelectorAll("script");
  for (const script of scripts) {
    const text = script.textContent || "";
    const match = text.match(/skuId['":\s]*['"]?(\d{6,})/);
    if (match) {
      return match[1];
    }
  }
  const meta = document.querySelector("meta[name='sku'], meta[property='product:sku']");
  if (meta) {
    return meta.getAttribute("content") || "";
  }
  const url = location.href;
  const urlMatch = url.match(/\/(\d{8,})/);
  const productId = urlMatch ? urlMatch[1] : "";
  const sizeSelect = collectSizeSelectElements()[0];
  if (sizeSelect && productId) {
    const sizeCode = sizeSelect.value;
    const colorSelect = Array.from(document.querySelectorAll("select")).find(
      (el) => /color/i.test(`${el.name} ${el.id} ${el.className}`)
    );
    const colorCode = colorSelect?.value?.split("-")?.[0] || "";
    return { productId, sizeCode, colorCode };
  }
  return null;
}

function extractNexProductId() {
  const addControl = findAddToCartControl();
  const controlId = addControl?.id || "";
  const controlMatch = controlId.match(/addToCart(\d{6,})/i);
  if (controlMatch) {
    return controlMatch[1];
  }

  const addForm = document.querySelector("form[id^='addToCartOptions']");
  if (addForm instanceof HTMLFormElement) {
    const formMatch = String(addForm.id || "").match(/addToCartOptions(\d{6,})/i);
    if (formMatch) {
      return formMatch[1];
    }
  }

  const urlMatch = location.href.match(/\/(\d{6,})/);
  return urlMatch ? urlMatch[1] : "";
}

function readNexCartCountFromDom() {
  const selectors = [
    "#cartCount",
    "[id='cartCount']",
    "a[href*='cart' i] .cart-count",
    "[class*='cart-count' i]"
  ];
  for (const selector of selectors) {
    const node = document.querySelector(selector);
    const text = String(node?.textContent || "").trim();
    const match = text.match(/\d+/);
    if (match) {
      return Number(match[0]);
    }
  }

  const cartLink = findByText("a, button, [role='button']", /^\d+$/);
  const fallbackMatch = String(cartLink?.textContent || "").trim().match(/^\d+$/);
  return fallbackMatch ? Number(fallbackMatch[0]) : null;
}

async function readNexCartCount(debug) {
  const domCount = readNexCartCountFromDom();
  if (Number.isFinite(domCount)) {
    return domCount;
  }

  try {
    const response = await fetch("/global/gadgets/totalCommerceItemCount.jsp", {
      credentials: "include",
      headers: { "X-Requested-With": "XMLHttpRequest" }
    });
    const json = await response.json();
    const parsed = Number(json?.cartcount);
    if (Number.isFinite(parsed)) {
      return parsed;
    }
  } catch (err) {
    debug.log(`cart-count: failed to read count ${err?.message || err}`);
  }

  return null;
}

async function waitForNexCartCountIncrease(previousCount, timeoutMs, pollMs, debug) {
  if (!Number.isFinite(previousCount)) {
    return false;
  }

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const currentCount = await readNexCartCount(debug);
    if (Number.isFinite(currentCount) && currentCount > previousCount) {
      debug.log(`cart-count: increased from ${previousCount} to ${currentCount}`);
      return true;
    }
    await sleep(pollMs);
  }

  debug.log(`cart-count: no increase detected from baseline ${previousCount}`);
  return false;
}

function buildFormEncodedBody(formEl) {
  if (!(formEl instanceof HTMLFormElement)) {
    return "";
  }
  return new URLSearchParams(new FormData(formEl)).toString();
}

async function nexAddToCartViaForm(debug) {
  const productId = extractNexProductId();
  if (!productId) {
    debug.log("form-add: missing productId");
    return false;
  }

  const form = document.getElementById(`addToCartOptions${productId}`);
  if (!(form instanceof HTMLFormElement)) {
    debug.log(`form-add: missing form addToCartOptions${productId}`);
    return false;
  }

  const body = buildFormEncodedBody(form);
  if (!body) {
    debug.log("form-add: serialized form was empty");
    return false;
  }

  debug.log(`form-add: posting validateAddToCart for productId=${productId}`);
  try {
    const response = await fetch("/global/gadgets/validateAddToCart.jsp", {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest"
      },
      body
    });

    const text = await response.text();
    let payload = null;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }

    if (!response.ok) {
      debug.log(`form-add: http ${response.status}`);
      debug.log(`form-add: response preview ${text.slice(0, 300)}`);
      return false;
    }

    if (String(payload?.error) === "false") {
      debug.log("form-add: validateAddToCart returned success");
      return true;
    }

    const exceptions = Array.isArray(payload?.exceptions) ? payload.exceptions.join("; ") : "";
    debug.log(`form-add: response error=${payload?.error} exceptions=${exceptions || "none"}`);
    debug.log(`form-add: response preview ${text.slice(0, 300)}`);
    return false;
  } catch (err) {
    debug.log(`form-add: fetch error ${err?.message || err}`);
    return false;
  }
}

async function nexDirectAddToCart(debug) {
  const formAddOk = await nexAddToCartViaForm(debug);
  if (formAddOk) {
    return true;
  }

  const skuInfo = extractNexSkuId();
  if (!skuInfo) {
    debug.log("direct-add: could not extract sku info");
    return false;
  }

  const { productId, sizeCode, colorCode } = typeof skuInfo === "object" ? skuInfo : {};
  if (!productId || !sizeCode) {
    debug.log("direct-add: missing productId or sizeCode");
    return false;
  }

  debug.log(`direct-add: looking up sku productId=${productId} size=${sizeCode} color=${colorCode}`);
  try {
    const lookupUrl = `/pdp/gadgets/skuBySizeColorLookup.jsp?productId=${productId}&sizeCode=${sizeCode}&colorCode=${colorCode}`;
    const lookupResp = await fetch(lookupUrl, { credentials: "include" });
    const lookupText = await lookupResp.text();
    const idMatch = lookupText.match(/"idval"\s*:\s*"(\d+)"/);
    const skuId = idMatch ? idMatch[1] : "";
    debug.log(`direct-add: sku lookup skuId=${skuId}`);
    if (!skuId) {
      debug.log(`direct-add: sku lookup failed, response: ${lookupText.slice(0, 300)}`);
      return false;
    }

    const addUrl = "/cart/gadgets/addItemToOrder.jsp";
    const body = new URLSearchParams({
      productId,
      catalogRefId: skuId,
      giftItemQty: "1",
      bopisLocationId: "sth",
      lockerParam: "false"
    });
    debug.log(`direct-add: posting to ${addUrl} with catalogRefId=${skuId}`);
    const addResp = await fetch(addUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest"
      },
      body: body.toString()
    });
    const addText = await addResp.text();
    const finalUrl = addResp.url || "";
    debug.log(`direct-add: status=${addResp.status} finalUrl=${finalUrl} length=${addText.length}`);
    debug.log(`direct-add: response preview: ${addText.slice(0, 400)}`);
    if (finalUrl.includes("sign-in") || addText.includes("Sign In")) {
      debug.log("direct-add: redirected to sign-in, session may have expired");
      return false;
    }
    return addResp.ok;
  } catch (err) {
    debug.log(`direct-add: fetch error ${err?.message || err}`);
    return false;
  }
}

async function clickWithRetry(getTarget, timeoutMs, pollMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const target = getTarget();
    if (target && clickElement(target)) {
      return true;
    }
    await sleep(pollMs);
  }
  return false;
}

function closeBlockingOverlays() {
  const closeBySelector = [
    "button[aria-label*='close' i]",
    "[role='dialog'] button[title*='close' i]",
    ".modal button.close",
    ".popup button.close",
    ".overlay button.close"
  ];
  for (const selector of closeBySelector) {
    const target = Array.from(document.querySelectorAll(selector)).find(
      (el) => el instanceof HTMLElement && isElementClickable(el) && isElementEnabled(el)
    );
    if (target instanceof HTMLElement) {
      clickElement(target);
      return true;
    }
  }

  const closeByText = findByText(
    "button, [role='button'], a",
    /close dialog|close|no thanks|dismiss|not now/i
  );
  if (closeByText) {
    clickElement(closeByText);
    return true;
  }
  return false;
}

function satisfyGatingInputs() {
  let changed = false;
  const actions = [];

  const checkboxes = Array.from(document.querySelectorAll("input[type='checkbox']")).filter(
    (input) => input instanceof HTMLInputElement && !input.checked && !input.disabled
  );
  for (const input of checkboxes) {
    const labelText = String(
      input.getAttribute("aria-label") ||
        input.closest("label")?.innerText ||
        input.parentElement?.innerText ||
        ""
    ).toLowerCase();
    if (/terms|policy|agree|confirm|authorized|household|shipping|store/.test(labelText)) {
      input.click();
      input.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      changed = true;
      actions.push(`checked ${labelText || input.name || "checkbox"}`);
    }
  }

  for (const radios of getRelevantRadioGroups().values()) {
    if (radios.some((radio) => radio.checked)) {
      continue;
    }
    const preferredRadio =
      radios.find((radio) => /sth|ship.*home|home/.test(`${radio.name} ${radio.value}`.toLowerCase())) ||
      radios.find((radio) => /sts|ship.*store|store|pickup/.test(`${radio.name} ${radio.value}`.toLowerCase())) ||
      radios[0];
    if (preferredRadio instanceof HTMLInputElement) {
      preferredRadio.click();
      preferredRadio.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      changed = true;
      actions.push(`selected ${preferredRadio.value || preferredRadio.name || "radio"}`);
    }
  }

  return { changed, actions };
}

function maybeClickEnableAddToCartLink() {
  const helperLink = findByText(
    "a, button, [role='button']",
    /select\s*store|choose\s*store|pickup\s*location|ship\s*to\s*store/i
  );
  if (helperLink) {
    clickElement(helperLink);
    return true;
  }
  return false;
}

async function addToCartWithRetries(preferredSizes = [], debug = createDebugRecorder(false)) {
  const maxAttempts = 6;
  let baselineCartCount = await readNexCartCount(debug);
  if (Number.isFinite(baselineCartCount)) {
    debug.log(`cart-count: baseline ${baselineCartCount}`);
  } else {
    debug.log("cart-count: baseline unavailable");
  }

  for (let i = 0; i < maxAttempts; i += 1) {
    const attempt = i + 1;
    const closedOverlay = closeBlockingOverlays();
    const gatingResult = satisfyGatingInputs();
    const sizeReady = ensurePreferredSizeSelected(preferredSizes);
    const helperClicked = maybeClickEnableAddToCartLink();
    debug.log(
      `attempt ${attempt}: overlayClosed=${closedOverlay} sizeReady=${sizeReady} radios=[${getRadioGroupSummary() || "none"}]`
    );
    if (gatingResult.actions.length) {
      debug.log(`attempt ${attempt}: gating actions -> ${gatingResult.actions.join("; ")}`);
    }
    if (helperClicked) {
      debug.log(`attempt ${attempt}: clicked store helper link`);
    }
    await sleep(400);

    const addControl = findAddToCartControl();
    debug.log(`attempt ${attempt}: add control ${describeAddToCartControl(addControl)}`);

    if (addControl) {
      const wasForced = forceEnableControl(addControl);
      if (wasForced) {
        debug.log(`attempt ${attempt}: force-removed readonly/disabled from add control`);
      }
    }

    const addButton = findAddToCartElement();
    if (addButton && clickElement(addButton)) {
      debug.log(`attempt ${attempt}: clicked add control directly`);
      await sleep(1200);
      if (
        !Number.isFinite(baselineCartCount) ||
        (await waitForNexCartCountIncrease(baselineCartCount, 3500, 300, debug))
      ) {
        return { ok: true, method: "click", attempts: attempt };
      }
      debug.log(`attempt ${attempt}: direct click did not change cart`);
    }

    if (addControl) {
      forceEnableControl(addControl);
      if (clickElement(addControl)) {
        debug.log(`attempt ${attempt}: force-clicked add control after enabling`);
        await sleep(1200);
        if (
          !Number.isFinite(baselineCartCount) ||
          (await waitForNexCartCountIncrease(baselineCartCount, 3500, 300, debug))
        ) {
          return { ok: true, method: "force-click", attempts: attempt };
        }
        debug.log(`attempt ${attempt}: force-click did not change cart`);
      }
    }

    if (addControl && forceSubmitFromAddControl(addControl)) {
      debug.log(`attempt ${attempt}: submitted add form fallback`);
      await sleep(1200);
      if (
        !Number.isFinite(baselineCartCount) ||
        (await waitForNexCartCountIncrease(baselineCartCount, 3500, 300, debug))
      ) {
        return { ok: true, method: "submit", attempts: attempt };
      }
      debug.log(`attempt ${attempt}: submit fallback did not change cart`);
    }
    debug.log(`attempt ${attempt}: add control still not actionable`);
    await sleep(600);
  }

  debug.log("all UI attempts exhausted, trying direct API add-to-cart");
  const directOk = await nexDirectAddToCart(debug);
  if (directOk) {
    await sleep(800);
    if (
      !Number.isFinite(baselineCartCount) ||
      (await waitForNexCartCountIncrease(baselineCartCount, 3500, 300, debug))
    ) {
      return { ok: true, method: "direct-api", attempts: maxAttempts + 1 };
    }
    debug.log("direct-add: request succeeded but cart count did not change");
  }

  return { ok: false, method: "", attempts: maxAttempts + 1 };
}

async function runMyNavyExchangeAssist(monitor = {}) {
  const stepDelayMs = Math.max(100, Math.min(30000, Number(monitor.actionFlowStepDelayMs) || 1400));
  const preferredSizes = Array.isArray(monitor.preferredSizes) ? monitor.preferredSizes : [];
  const debug = createDebugRecorder(Boolean(monitor.debugEnabled));
  let clicked = 0;

  debug.log(`start assist url=${location.href}`);
  debug.log(`preferred sizes=${preferredSizes.join(", ") || "auto"}`);

  const closedOverlay = closeBlockingOverlays();
  const initialGating = satisfyGatingInputs();
  debug.log(`initial overlayClosed=${closedOverlay}`);
  if (initialGating.actions.length) {
    debug.log(`initial gating -> ${initialGating.actions.join("; ")}`);
  }

  const sizeSelectedFromDropdown = ensurePreferredSizeSelected(preferredSizes);
  debug.log(`size after select=${getSelectedSizeSummary() || "none"}`);

  const preferredSizeEl = findPreferredSizeElement(preferredSizes);
  const sizeClicked =
    sizeSelectedFromDropdown ||
    (preferredSizeEl ? clickElement(preferredSizeEl) : false) ||
    tryClickBySelectors([
      ".product-size button:not([disabled])",
      ".size-selector button:not([disabled])",
      "[data-option*='size' i] button:not([disabled])",
      "[class*='size' i] button:not([disabled])",
      "[class*='size' i] [role='button']:not([aria-disabled='true'])"
    ]) ||
    clickElement(
      findByText("button, [role='button'], label", /(size|\\d+\\s?(m|w|y|us)?)/i)
    );

  if (sizeClicked) {
    clicked += 1;
    debug.log(`size interaction completed, waiting for async controls`);
    await sleep(Math.max(stepDelayMs, 2500));
  }

  const sizeReapplied = ensurePreferredSizeSelected(preferredSizes);
  const secondaryGating = satisfyGatingInputs();
  debug.log(
    `pre-add state size=${getSelectedSizeSummary() || "none"} sizeReapplied=${sizeReapplied} radios=[${getRadioGroupSummary() || "none"}]`
  );
  if (secondaryGating.actions.length) {
    debug.log(`pre-add gating -> ${secondaryGating.actions.join("; ")}`);
  }
  await sleep(500);

  const addResult = await addToCartWithRetries(preferredSizes, debug);
  if (!addResult.ok) {
    debug.log(`final add state=${describeAddToCartControl(findAddToCartControl())}`);
    saveAssistDebug(debug.snapshot());
    return {
      ok: false,
      clicked,
      total: 4,
      error: "Could not activate Add to Cart (check login/store eligibility for this item)",
      debugTrace: debug.snapshot()
    };
  }
  clicked += 1;
  debug.log(`add to cart succeeded via ${addResult.method} on attempt ${addResult.attempts}`);
  await sleep(stepDelayMs);

  const cartClicked = await clickWithRetry(
    () =>
      findByText("a, button, [role='button']", /view\\s*cart|go\\s*to\\s*cart|cart/i) ||
      document.querySelector("a[href*='cart' i], button[class*='cart' i]"),
    8000,
    350
  );
  if (!cartClicked) {
    debug.log(`cart open failed`);
    saveAssistDebug(debug.snapshot());
    return { ok: false, clicked, total: 4, error: "Could not open cart", debugTrace: debug.snapshot() };
  }
  clicked += 1;
  debug.log(`cart opened`);
  await sleep(stepDelayMs);

  const checkoutClicked = await clickWithRetry(
    () =>
      findByText("a, button, input[type='submit'], [role='button']", /checkout|proceed\\s*to\\s*checkout/i) ||
      document.querySelector("a[href*='checkout' i], button[name*='checkout' i]"),
    8000,
    350
  );
  if (!checkoutClicked) {
    debug.log(`checkout action not found`);
    saveAssistDebug(debug.snapshot());
    return {
      ok: false,
      clicked,
      total: 4,
      error: "Could not find checkout action",
      debugTrace: debug.snapshot()
    };
  }
  clicked += 1;
  debug.log(`checkout clicked`);
  saveAssistDebug(debug.snapshot());

  return { ok: true, clicked, total: 4, debugTrace: debug.snapshot() };
}

function parseRegex(value) {
  if (!value) {
    return null;
  }
  const trimmed = value.trim();
  const regexLike = trimmed.match(/^\/(.+)\/([gimsuy]*)$/);
  if (regexLike) {
    return new RegExp(regexLike[1], regexLike[2] || "i");
  }
  return new RegExp(trimmed, "i");
}

function evaluateExpression({ expressionType, keyword, sourceText }) {
  if (!keyword) {
    return false;
  }

  if (expressionType === "regex") {
    try {
      return parseRegex(keyword)?.test(sourceText) || false;
    } catch {
      return false;
    }
  }

  if (expressionType === "xpath") {
    try {
      const result = document.evaluate(
        keyword,
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      );
      return Boolean(result.singleNodeValue);
    } catch {
      return false;
    }
  }

  return sourceText.toLowerCase().includes(keyword.toLowerCase());
}

function evaluateNegativeKeywords(sourceText, negativeKeywords = []) {
  const normalized = sourceText.toLowerCase();
  const matches = negativeKeywords
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .filter((item) => normalized.includes(item.toLowerCase()));

  return {
    hasNegativeMatch: matches.length > 0,
    matchedKeywords: matches
  };
}

function ensureOverlay() {
  let el = document.getElementById(OVERLAY_ID);
  if (!el) {
    el = document.createElement("div");
    el.id = OVERLAY_ID;
    el.style.position = "fixed";
    el.style.bottom = "12px";
    el.style.right = "12px";
    el.style.zIndex = "2147483647";
    el.style.background = "rgba(22, 22, 22, 0.82)";
    el.style.color = "#fff";
    el.style.padding = "6px 10px";
    el.style.borderRadius = "8px";
    el.style.fontSize = "12px";
    el.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
    el.style.pointerEvents = "none";
    el.style.boxShadow = "0 4px 14px rgba(0,0,0,.28)";
    document.documentElement.appendChild(el);
  }
  return el;
}

function removeOverlay() {
  if (timerIntervalId) {
    clearInterval(timerIntervalId);
    timerIntervalId = null;
  }
  const el = document.getElementById(OVERLAY_ID);
  if (el) {
    el.remove();
  }
}

function startOrUpdateTimer(nextAt, visible) {
  if (!visible) {
    removeOverlay();
    return;
  }

  if (timerIntervalId) {
    clearInterval(timerIntervalId);
  }

  const el = ensureOverlay();

  const render = () => {
    const diff = Math.max(0, nextAt - Date.now());
    const sec = Math.ceil(diff / 1000);
    el.textContent = `Page Monitor refresh in ${sec}s`;
  };

  render();
  timerIntervalId = window.setInterval(render, 1000);
}

function notifyInteraction() {
  chrome.runtime.sendMessage({
    type: "PM_USER_INTERACTION_STOP",
    tabId: undefined
  });
}

function installInteractionHooks() {
  if (interactionHooksEnabled) {
    return;
  }
  interactionHooksEnabled = true;
  window.addEventListener("click", notifyInteraction, true);
  window.addEventListener("keydown", notifyInteraction, true);
  window.addEventListener("input", notifyInteraction, true);
}

function removeInteractionHooks() {
  if (!interactionHooksEnabled) {
    return;
  }
  interactionHooksEnabled = false;
  window.removeEventListener("click", notifyInteraction, true);
  window.removeEventListener("keydown", notifyInteraction, true);
  window.removeEventListener("input", notifyInteraction, true);
}

function getAudioContext() {
  const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextCtor) {
    return null;
  }
  if (!alertAudioCtx) {
    alertAudioCtx = new AudioContextCtor();
  }
  return alertAudioCtx;
}

async function playAlertSound(soundConfig = {}) {
  const ctx = getAudioContext();
  if (!ctx) {
    return false;
  }
  if (ctx.state === "suspended") {
    try {
      await ctx.resume();
    } catch {
      return false;
    }
  }

  const volume = Math.max(0, Math.min(1, Number(soundConfig.volume) || 0.6));
  const repeatCount = Math.max(1, Math.min(5, Number(soundConfig.repeatCount) || 1));
  const frequencyHz = Math.max(220, Math.min(2200, Number(soundConfig.frequencyHz) || 880));
  const now = ctx.currentTime;

  for (let i = 0; i < repeatCount; i += 1) {
    const startAt = now + i * 0.26;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = frequencyHz;
    gain.gain.setValueAtTime(0.0001, startAt);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.01, volume), startAt + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, startAt + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startAt);
    osc.stop(startAt + 0.22);
  }
  return true;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "PM_EVALUATE_MONITOR") {
    const monitor = message.monitor || {};
    const sourceText = getSourceText(monitor.source || "visible");
    const newHash = hashString(sourceText);
    const negativeResult = evaluateNegativeKeywords(sourceText, monitor.negativeKeywords || []);
    const positive = evaluateExpression({
      expressionType: monitor.expressionType || "text",
      keyword: monitor.keyword || "",
      sourceText
    });

    let matched = false;
    let detail = "";
    const mode = monitor.mode || "appears";
    if (mode === "appears") {
      matched = positive && !negativeResult.hasNegativeMatch;
      detail = "Keyword appeared";
    } else if (mode === "disappears") {
      matched = !positive;
      detail = "Keyword disappeared";
    } else if (mode === "negative_match") {
      matched = negativeResult.hasNegativeMatch;
      detail = negativeResult.hasNegativeMatch
        ? `Negative keyword(s): ${negativeResult.matchedKeywords.join(", ")}`
        : "No negative keywords";
    } else if (mode === "any_change") {
      const previousHash = String(message.previousHash || "");
      matched = Boolean(previousHash) && previousHash !== newHash;
      detail = "Page content changed";
    }

    sendResponse({
      matched,
      hasNegativeMatch: negativeResult.hasNegativeMatch,
      detail,
      newHash
    });
    return true;
  }

  if (message?.type === "PM_AUTO_CLICK") {
    const selector = String(message.selector || "").trim();
    if (!selector) {
      sendResponse({ ok: false });
      return true;
    }
    const candidates = Array.from(document.querySelectorAll(selector));
    const target = candidates.find((el) => isElementClickable(el)) || candidates[0];
    if (target instanceof HTMLElement) {
      target.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
      target.click();
      sendResponse({ ok: true });
    } else {
      sendResponse({ ok: false });
    }
    return true;
  }

  if (message?.type === "PM_RUN_SITE_ASSIST" && message?.site === "mynavyexchange") {
    runMyNavyExchangeAssist(message.monitor || {})
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: String(err?.message || err) }));
    return true;
  }

  if (message?.type === "PM_GET_ASSIST_DEBUG") {
    sendResponse({ ok: true, debugTrace: lastAssistDebug.slice() });
    return true;
  }

  if (message?.type === "PM_TIMER_UPDATE") {
    startOrUpdateTimer(Number(message.nextAt) || Date.now(), Boolean(message.showVisualTimer));
    if (message.stopOnInteraction) {
      installInteractionHooks();
    } else {
      removeInteractionHooks();
    }
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "PM_TIMER_STOP") {
    removeOverlay();
    removeInteractionHooks();
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "PM_STATUS") {
    const el = ensureOverlay();
    const text = String(message.text || "Status updated");
    el.textContent = text;
    window.setTimeout(() => {
      const current = document.getElementById(OVERLAY_ID);
      if (current && current.textContent === text) {
        current.remove();
      }
    }, 1800);
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "PM_PLAY_ALERT_SOUND") {
    playAlertSound(message.sound || {})
      .then((ok) => sendResponse({ ok }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  return false;
});
