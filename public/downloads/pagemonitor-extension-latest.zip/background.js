const TAB_CONFIGS_KEY = "tabConfigs";
const SETTINGS_KEY = "globalSettings";
const ALARM_PREFIX = "refresh:";

const DEFAULT_TAB_CONFIG = {
  enabled: false,
  refresh: {
    mode: "interval", // interval | random
    intervalSec: 30,
    randomMinSec: 20,
    randomMaxSec: 40,
    countdownSec: 0,
    limit: 0,
    hardRefresh: false,
    showVisualTimer: true,
    stopOnInteraction: false
  },
  monitor: {
    enabled: false,
    mode: "appears", // appears | disappears | any_change | negative_match
    expressionType: "text", // text | regex | xpath
    keyword: "",
    negativeKeywords: [],
    source: "visible", // visible | html
    stopOnMatch: false,
    continueRefreshingOnMatch: true,
    notifyOnMatch: true,
    autoClickSelector: "",
    debugEnabled: false,
    runActionFlowOnMatch: false,
    actionFlowSteps: [],
    preferredSizes: [],
    actionFlowStepDelayMs: 1200
  },
  runtime: {
    completed: 0,
    lastContentHash: "",
    nextAt: 0
  }
};

const DEFAULT_SETTINGS = {
  autoStartRules: [],
  predefinedUrls: [],
  remoteNotifications: {
    enabled: false,
    webhookUrl: "",
    authToken: "",
    cooldownSec: 60
  },
  soundNotifications: {
    enabled: true,
    volume: 0.6,
    repeatCount: 2,
    frequencyHz: 880
  },
  defaultTabConfig: DEFAULT_TAB_CONFIG
};

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

async function getStorage(keys) {
  return chrome.storage.local.get(keys);
}

async function setStorage(data) {
  return chrome.storage.local.set(data);
}

async function getTabConfigs() {
  const data = await getStorage([TAB_CONFIGS_KEY]);
  return data[TAB_CONFIGS_KEY] || {};
}

async function saveTabConfigs(configs) {
  await setStorage({ [TAB_CONFIGS_KEY]: configs });
}

async function getSettings() {
  const data = await getStorage([SETTINGS_KEY]);
  const saved = data[SETTINGS_KEY] || {};
  return {
    ...deepClone(DEFAULT_SETTINGS),
    ...saved,
    remoteNotifications: {
      ...deepClone(DEFAULT_SETTINGS.remoteNotifications),
      ...(saved.remoteNotifications || {})
    },
    soundNotifications: {
      ...deepClone(DEFAULT_SETTINGS.soundNotifications),
      ...(saved.soundNotifications || {})
    },
    defaultTabConfig: {
      ...deepClone(DEFAULT_TAB_CONFIG),
      ...(saved.defaultTabConfig || {}),
      refresh: {
        ...deepClone(DEFAULT_TAB_CONFIG.refresh),
        ...(saved.defaultTabConfig?.refresh || {})
      },
      monitor: {
        ...deepClone(DEFAULT_TAB_CONFIG.monitor),
        ...(saved.defaultTabConfig?.monitor || {})
      },
      runtime: {
        ...deepClone(DEFAULT_TAB_CONFIG.runtime),
        ...(saved.defaultTabConfig?.runtime || {})
      }
    }
  };
}

function alarmName(tabId) {
  return `${ALARM_PREFIX}${tabId}`;
}

function parseTabIdFromAlarm(name) {
  if (!name.startsWith(ALARM_PREFIX)) {
    return null;
  }
  return Number(name.slice(ALARM_PREFIX.length));
}

function wildcardToRegExp(pattern) {
  const escaped = pattern
    .replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*/g, ".*");
  return new RegExp(`^${escaped}$`, "i");
}

function normalizeUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.href;
  } catch {
    return url;
  }
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function computeDelayMs(config, firstRun = false) {
  if (firstRun && Number(config.refresh.countdownSec) > 0) {
    return Math.max(100, Number(config.refresh.countdownSec) * 1000);
  }

  if (config.refresh.mode === "random") {
    const minSec = Number(config.refresh.randomMinSec) || 1;
    const maxSec = Number(config.refresh.randomMaxSec) || minSec;
    const low = Math.max(0.1, Math.min(minSec, maxSec));
    const high = Math.max(low, Math.max(minSec, maxSec));
    return Math.round((low + Math.random() * (high - low)) * 1000);
  }

  const intervalSec = Number(config.refresh.intervalSec) || 30;
  return Math.max(100, Math.round(intervalSec * 1000));
}

async function safeSendMessage(tabId, payload) {
  try {
    return await chrome.tabs.sendMessage(tabId, payload);
  } catch {
    return null;
  }
}

async function clickSelectorOnTab(tabId, selector) {
  const result = await safeSendMessage(tabId, {
    type: "PM_AUTO_CLICK",
    selector
  });
  return Boolean(result?.ok);
}

async function runMyNavyExchangeAssist(tabId, monitor = {}) {
  const result = await safeSendMessage(tabId, {
    type: "PM_RUN_SITE_ASSIST",
    site: "mynavyexchange",
    monitor
  });
  if (!result) {
    return { ok: false, clicked: 0, total: 0, error: "Could not run site assist script" };
  }
  return result;
}

async function getAssistDebugTrace(tabId) {
  const result = await safeSendMessage(tabId, { type: "PM_GET_ASSIST_DEBUG" });
  return Array.isArray(result?.debugTrace) ? result.debugTrace : [];
}

async function runActionFlow(tabId, monitor = {}, options = {}) {
  let tabUrl = "";
  try {
    const tab = await chrome.tabs.get(tabId);
    tabUrl = String(tab?.url || "");
  } catch {
    tabUrl = "";
  }
  const siteProfile = String(monitor.siteProfile || "").trim().toLowerCase();
  const assistMode = String(monitor.assistMode || "site_builtin").trim().toLowerCase();
  const shouldUseSiteAssist =
    assistMode !== "custom_selectors" &&
    (siteProfile === "mynavyexchange" || tabUrl.includes("mynavyexchange.com"));
  if (shouldUseSiteAssist) {
    const siteResult = await runMyNavyExchangeAssist(tabId, monitor);
    if (siteResult.ok) {
      return siteResult;
    }
  }

  const rawSteps = Array.isArray(monitor.actionFlowSteps) ? monitor.actionFlowSteps : [];
  const steps = rawSteps.map((item) => String(item || "").trim()).filter(Boolean);
  if (!steps.length) {
    return {
      ok: false,
      clicked: 0,
      total: 0,
      error: "No action flow steps configured"
    };
  }

  const stepDelayMs = Math.max(100, Math.min(30000, Number(monitor.actionFlowStepDelayMs) || 1200));
  const stepTimeoutMs = Math.max(
    2000,
    Math.min(60000, Number(options.stepTimeoutMs) || Math.max(8000, stepDelayMs * 5))
  );

  let clicked = 0;
  let failedSelector = "";

  for (const selector of steps) {
    let stepMatched = false;
    const deadline = Date.now() + stepTimeoutMs;
    while (Date.now() < deadline) {
      if (await clickSelectorOnTab(tabId, selector)) {
        clicked += 1;
        stepMatched = true;
        await sleep(stepDelayMs);
        break;
      }
      await sleep(350);
    }
    if (!stepMatched) {
      failedSelector = selector;
      break;
    }
  }

  return {
    ok: clicked === steps.length,
    clicked,
    total: steps.length,
    failedSelector,
    error: clicked === steps.length ? "" : `Could not find selector: ${failedSelector}`
  };
}

async function updateVisualTimer(tabId, config) {
  if (!config?.enabled) {
    await safeSendMessage(tabId, { type: "PM_TIMER_STOP" });
    return;
  }
  await safeSendMessage(tabId, {
    type: "PM_TIMER_UPDATE",
    nextAt: config.runtime.nextAt,
    showVisualTimer: Boolean(config.refresh.showVisualTimer),
    stopOnInteraction: Boolean(config.refresh.stopOnInteraction)
  });
}

async function scheduleNext(tabId, config, firstRun = false) {
  const delayMs = computeDelayMs(config, firstRun);
  const when = Date.now() + delayMs;
  config.runtime.nextAt = when;
  await chrome.alarms.create(alarmName(tabId), { when });
  await updateVisualTimer(tabId, config);
}

async function notify(title, message) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/w8AAnsB9s4nHCkAAAAASUVORK5CYII=",
      title,
      message
    });
  } catch {
    // Notifications can fail in some environments; ignore.
  }
}

async function notifyRemote(settings, payload) {
  const remote = settings?.remoteNotifications || {};
  if (!remote.enabled || !remote.webhookUrl) {
    return false;
  }

  const headers = {
    "Content-Type": "application/json"
  };
  if (remote.authToken) {
    headers.Authorization = `Bearer ${remote.authToken}`;
  }

  try {
    const response = await fetch(remote.webhookUrl, {
      method: "POST",
      headers,
      body: JSON.stringify(payload)
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function maybeNotifyRemote(settings, tab, cfg, eventType, detail) {
  const cooldownSec = Math.max(0, Number(settings?.remoteNotifications?.cooldownSec) || 60);
  const now = Date.now();
  const lastSentAt = Number(cfg.runtime?.lastRemoteSentAt) || 0;
  const lastSignature = String(cfg.runtime?.lastRemoteSignature || "");
  const signature = `${eventType}:${detail || ""}`;

  if (cooldownSec > 0 && signature === lastSignature && now - lastSentAt < cooldownSec * 1000) {
    return false;
  }

  const ok = await notifyRemote(settings, {
    source: "Page Monitor Pro",
    eventType,
    detail: detail || "",
    title: tab?.title || "",
    url: tab?.url || "",
    tabId: tab?.id || null,
    timestamp: new Date().toISOString(),
    completedRefreshes: Number(cfg.runtime?.completed) || 0
  });

  if (ok) {
    cfg.runtime.lastRemoteSentAt = now;
    cfg.runtime.lastRemoteSignature = signature;
  }
  return ok;
}

async function maybePlaySound(tabId, settings, eventType) {
  const sound = settings?.soundNotifications || {};
  if (!sound.enabled) {
    return false;
  }
  const payload = {
    type: "PM_PLAY_ALERT_SOUND",
    sound: {
      volume: Math.max(0, Math.min(1, Number(sound.volume) || 0.6)),
      repeatCount: Math.max(1, Math.min(5, Number(sound.repeatCount) || 1)),
      frequencyHz: Math.max(220, Math.min(2200, Number(sound.frequencyHz) || 880)),
      eventType
    }
  };
  const result = await safeSendMessage(tabId, payload);
  return Boolean(result?.ok);
}

async function stopTabTask(tabId, reason = "Stopped") {
  const configs = await getTabConfigs();
  const cfg = configs[String(tabId)];
  if (!cfg) {
    return;
  }
  cfg.enabled = false;
  cfg.runtime.nextAt = 0;
  configs[String(tabId)] = cfg;
  await saveTabConfigs(configs);
  await chrome.alarms.clear(alarmName(tabId));
  await safeSendMessage(tabId, { type: "PM_TIMER_STOP" });
  if (reason) {
    await safeSendMessage(tabId, { type: "PM_STATUS", text: reason });
  }
}

async function startTabTask(tabId, incomingConfig) {
  const configs = await getTabConfigs();
  const existing = configs[String(tabId)] || deepClone(DEFAULT_TAB_CONFIG);
  const merged = {
    ...deepClone(DEFAULT_TAB_CONFIG),
    ...existing,
    ...incomingConfig,
    refresh: {
      ...deepClone(DEFAULT_TAB_CONFIG.refresh),
      ...(existing.refresh || {}),
      ...(incomingConfig?.refresh || {})
    },
    monitor: {
      ...deepClone(DEFAULT_TAB_CONFIG.monitor),
      ...(existing.monitor || {}),
      ...(incomingConfig?.monitor || {})
    },
    runtime: {
      ...deepClone(DEFAULT_TAB_CONFIG.runtime),
      completed: 0,
      lastContentHash: existing.runtime?.lastContentHash || "",
      lastRemoteSentAt: existing.runtime?.lastRemoteSentAt || 0,
      lastRemoteSignature: existing.runtime?.lastRemoteSignature || "",
      nextAt: 0
    },
    enabled: true
  };

  configs[String(tabId)] = merged;
  await saveTabConfigs(configs);
  await scheduleNext(tabId, merged, true);
}

async function evaluateMonitor(tabId, config) {
  if (!config.monitor.enabled) {
    return { matched: false, hasNegativeMatch: false };
  }
  const result = await safeSendMessage(tabId, {
    type: "PM_EVALUATE_MONITOR",
    monitor: config.monitor,
    previousHash: config.runtime.lastContentHash
  });

  if (!result) {
    return { matched: false, hasNegativeMatch: false };
  }

  return {
    matched: Boolean(result.matched),
    hasNegativeMatch: Boolean(result.hasNegativeMatch),
    detail: result.detail || "",
    newHash: result.newHash || ""
  };
}

async function runRefreshCycle(tabId) {
  const configs = await getTabConfigs();
  const cfg = configs[String(tabId)];
  if (!cfg?.enabled) {
    await chrome.alarms.clear(alarmName(tabId));
    return;
  }

  let tab;
  try {
    tab = await chrome.tabs.get(tabId);
  } catch {
    delete configs[String(tabId)];
    await saveTabConfigs(configs);
    return;
  }

  if (!tab || !tab.url || tab.url.startsWith("chrome://")) {
    await scheduleNext(tabId, cfg, false);
    configs[String(tabId)] = cfg;
    await saveTabConfigs(configs);
    return;
  }
  const settings = await getSettings();

  const monitorResult = await evaluateMonitor(tabId, cfg);
  if (monitorResult.newHash) {
    cfg.runtime.lastContentHash = monitorResult.newHash;
  }

  if (cfg.monitor.enabled) {
    let soundPlayed = false;
    if (monitorResult.hasNegativeMatch) {
      await notify("Negative keyword detected", tab.title || tab.url);
      await maybeNotifyRemote(settings, tab, cfg, "negative_keyword", monitorResult.detail || "Negative keyword detected");
      soundPlayed = await maybePlaySound(tabId, settings, "negative_keyword");
    }

    if (monitorResult.matched && cfg.monitor.notifyOnMatch) {
      await notify("Page monitor matched", `${tab.title || tab.url}${monitorResult.detail ? `: ${monitorResult.detail}` : ""}`);
    }
    if (monitorResult.matched) {
      await maybeNotifyRemote(settings, tab, cfg, "monitor_match", monitorResult.detail || "Monitor matched");
      if (!soundPlayed) {
        await maybePlaySound(tabId, settings, "monitor_match");
      }
    }

    if (monitorResult.matched && cfg.monitor.runActionFlowOnMatch) {
      const flowResult = await runActionFlow(tabId, cfg.monitor);
      if (!flowResult.ok) {
        await notify(
          "Checkout assist incomplete",
          flowResult.error || `Completed ${flowResult.clicked}/${flowResult.total} actions`
        );
      }
    } else if (monitorResult.matched && cfg.monitor.autoClickSelector) {
      await safeSendMessage(tabId, {
        type: "PM_AUTO_CLICK",
        selector: cfg.monitor.autoClickSelector
      });
    }

    if (monitorResult.matched && cfg.monitor.stopOnMatch) {
      await stopTabTask(tabId, "Stopped: monitor match");
      return;
    }
  }

  const limit = Number(cfg.refresh.limit) || 0;
  if (limit > 0 && cfg.runtime.completed >= limit) {
    await stopTabTask(tabId, "Stopped: refresh limit reached");
    return;
  }

  try {
    await chrome.tabs.reload(tabId, { bypassCache: Boolean(cfg.refresh.hardRefresh) });
    cfg.runtime.completed += 1;
  } catch {
    // Keep task alive even if reload fails once.
  }

  if (limit > 0 && cfg.runtime.completed >= limit) {
    configs[String(tabId)] = cfg;
    await saveTabConfigs(configs);
    await stopTabTask(tabId, "Stopped: refresh limit reached");
    return;
  }

  configs[String(tabId)] = cfg;
  await saveTabConfigs(configs);
  await scheduleNext(tabId, cfg, false);
}

async function maybeAutoStart(tab) {
  if (!tab?.id || !tab.url) {
    return;
  }
  const settings = await getSettings();
  const rules = settings.autoStartRules || [];
  if (!rules.length) {
    return;
  }

  const url = normalizeUrl(tab.url);
  const matchedRule = rules.find((rule) => {
    if (!rule?.enabled || !rule?.pattern) {
      return false;
    }
    return wildcardToRegExp(rule.pattern).test(url);
  });

  if (!matchedRule) {
    return;
  }

  const configs = await getTabConfigs();
  const existing = configs[String(tab.id)];
  if (existing?.enabled) {
    return;
  }

  const defaults = settings.defaultTabConfig || DEFAULT_TAB_CONFIG;
  await startTabTask(tab.id, {
    ...deepClone(defaults),
    ...(matchedRule.config || {}),
    enabled: true
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  const settings = await getSettings();
  await setStorage({ [SETTINGS_KEY]: settings });
  const tabConfigs = await getTabConfigs();
  await setStorage({ [TAB_CONFIGS_KEY]: tabConfigs });
});

chrome.runtime.onStartup.addListener(async () => {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    await maybeAutoStart(tab);
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    await maybeAutoStart(tab);
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await chrome.alarms.clear(alarmName(tabId));
  const configs = await getTabConfigs();
  if (configs[String(tabId)]) {
    delete configs[String(tabId)];
    await saveTabConfigs(configs);
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const tabId = parseTabIdFromAlarm(alarm.name);
  if (tabId === null) {
    return;
  }
  await runRefreshCycle(tabId);
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "stop_all") {
    const configs = await getTabConfigs();
    const tabIds = Object.keys(configs).map(Number);
    await Promise.all(tabIds.map((tabId) => stopTabTask(tabId, "Stopped by hotkey")));
    return;
  }

  if (command === "start_or_stop_tab") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      return;
    }
    const configs = await getTabConfigs();
    const existing = configs[String(tab.id)];
    if (existing?.enabled) {
      await stopTabTask(tab.id, "Stopped by hotkey");
      return;
    }
    const settings = await getSettings();
    await startTabTask(tab.id, settings.defaultTabConfig || deepClone(DEFAULT_TAB_CONFIG));
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "PM_GET_TAB_STATE") {
      const tabId = Number(message.tabId);
      const configs = await getTabConfigs();
      sendResponse({
        ok: true,
        config: configs[String(tabId)] || deepClone(DEFAULT_TAB_CONFIG)
      });
      return;
    }

    if (message?.type === "PM_SAVE_TAB_CONFIG") {
      const tabId = Number(message.tabId);
      const configs = await getTabConfigs();
      const existing = configs[String(tabId)] || deepClone(DEFAULT_TAB_CONFIG);
      const next = {
        ...existing,
        ...message.config,
        refresh: { ...existing.refresh, ...(message.config?.refresh || {}) },
        monitor: { ...existing.monitor, ...(message.config?.monitor || {}) },
        runtime: { ...existing.runtime, ...(message.config?.runtime || {}) }
      };
      configs[String(tabId)] = next;
      await saveTabConfigs(configs);
      sendResponse({ ok: true, config: next });
      return;
    }

    if (message?.type === "PM_START_TAB") {
      await startTabTask(Number(message.tabId), message.config || {});
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "PM_STOP_TAB") {
      await stopTabTask(Number(message.tabId), "Stopped");
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "PM_STOP_ALL") {
      const configs = await getTabConfigs();
      const tabIds = Object.keys(configs).map(Number);
      await Promise.all(tabIds.map((tabId) => stopTabTask(tabId, "Stopped all tasks")));
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "PM_RUN_ACTION_FLOW") {
      const tabId = Number(message.tabId);
      if (!tabId) {
        sendResponse({ ok: false, error: "Missing tab id" });
        return;
      }
      const monitor = message.monitor || {};
      const result = await runActionFlow(tabId, monitor);
      sendResponse(result);
      return;
    }

    if (message?.type === "PM_GET_ASSIST_DEBUG") {
      const tabId = Number(message.tabId);
      if (!tabId) {
        sendResponse({ ok: false, debugTrace: [] });
        return;
      }
      const debugTrace = await getAssistDebugTrace(tabId);
      sendResponse({ ok: true, debugTrace });
      return;
    }

    if (message?.type === "PM_GET_ACTIVE_TABS") {
      const configs = await getTabConfigs();
      const entries = Object.entries(configs).filter(([, cfg]) => cfg?.enabled);
      const activeTabs = [];
      for (const [id, cfg] of entries) {
        try {
          const tab = await chrome.tabs.get(Number(id));
          activeTabs.push({
            tabId: Number(id),
            title: tab.title || tab.url,
            url: tab.url || "",
            nextAt: cfg.runtime?.nextAt || 0,
            completed: cfg.runtime?.completed || 0,
            limit: cfg.refresh?.limit || 0
          });
        } catch {
          // Ignore stale tabs.
        }
      }
      sendResponse({ ok: true, activeTabs });
      return;
    }

    if (message?.type === "PM_GET_SETTINGS") {
      sendResponse({ ok: true, settings: await getSettings() });
      return;
    }

    if (message?.type === "PM_SAVE_SETTINGS") {
      const current = await getSettings();
      const merged = { ...current, ...(message.settings || {}) };
      await setStorage({ [SETTINGS_KEY]: merged });
      sendResponse({ ok: true, settings: merged });
      return;
    }

    if (message?.type === "PM_TEST_SOUND") {
      const settings = await getSettings();
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab" });
        return;
      }
      const ok = await maybePlaySound(tab.id, settings, "test");
      sendResponse({ ok });
      return;
    }

    if (message?.type === "PM_USER_INTERACTION_STOP") {
      const senderTabId = sender?.tab?.id;
      const incomingTabId = Number(message.tabId);
      const tabId = Number.isFinite(incomingTabId) ? incomingTabId : senderTabId;
      if (!tabId) {
        sendResponse({ ok: false, error: "Missing tab id" });
        return;
      }
      const configs = await getTabConfigs();
      const cfg = configs[String(tabId)];
      if (cfg?.enabled && cfg.refresh?.stopOnInteraction) {
        await stopTabTask(Number(tabId), "Stopped on interaction");
      }
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, error: "Unknown message type" });
  })();
  return true;
});
