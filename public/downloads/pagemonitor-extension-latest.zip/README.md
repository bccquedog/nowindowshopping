# Page Monitor Pro (Chrome Extension, MV3)

`Page Monitor Pro` is a Chrome extension for auto-refresh + page monitoring, inspired by Auto Refresh Plus style workflows, with built-in **negative keyword** support.

## Implemented features

- Default interval refresh
- Random interval refresh (min/max)
- Countdown start
- Refresh limit (N cycles)
- Hard refresh (bypass cache)
- Visual timer overlay on page
- Stop on user interaction (click/typing)
- Active tabs list in popup
- Page monitor modes:
  - keyword appears
  - keyword disappears
  - any page change
  - negative keyword appears
- Expression types:
  - text
  - regex
  - xpath
- Monitoring source:
  - visible text
  - html source
- Auto-click selector when monitor matches
- Browser notifications on match
- Remote webhook notifications (for away-from-device alerts)
- Configurable sound notifications (volume/repeat/tone)
- Auto-start URL rules (options page)
- Keyboard shortcuts (commands):
  - start/stop current tab
  - stop all

## Negative keywords

In the popup, set **Negative keywords** as comma-separated or newline-separated values.

Example:

- Positive keyword: `in stock`
- Negative keywords:
  - `sold out`
  - `unavailable`

With monitor mode **Keyword appears**, a match requires:

1. Positive keyword found
2. None of the negative keywords present

With monitor mode **Negative keyword appears**, any negative keyword triggers the match.

## Remote notifications

To get alerts while away from your computer:

1. Open extension **Options**
2. Enable **Remote webhook notifications**
3. Paste your webhook URL
4. (Optional) Add auth token
5. Set cooldown seconds

When triggered, the extension sends JSON like:

```json
{
  "source": "Page Monitor Pro",
  "eventType": "monitor_match",
  "detail": "Keyword appeared",
  "title": "Page title",
  "url": "https://example.com/",
  "tabId": 123,
  "timestamp": "2026-03-07T18:00:00.000Z",
  "completedRefreshes": 4
}
```

## Sound notifications

In **Options**, you can:

- Enable/disable sound alerts
- Set volume
- Set repeat count
- Set tone frequency
- Use **Test sound** to verify setup on the active tab

## Load in Chrome

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select this folder: `/Users/brianproctor/pagemonitor`

## Notes

- This is a strong functional baseline, not a byte-for-byte clone of Auto Refresh Plus.
