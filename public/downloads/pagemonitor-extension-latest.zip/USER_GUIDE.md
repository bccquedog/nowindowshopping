# Page Monitor Pro - User Guide

This guide explains how to install and use `Page Monitor Pro` for auto-refresh and keyword monitoring, including negative keywords, remote alerts, and sound notifications.

## 1) Install the extension

1. Unzip the extension package to a folder.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked**.
5. Select the unzipped folder (the folder that contains `manifest.json`).

## 2) Quick start (first monitor)

1. Open a page you want to monitor.
2. Click the extension icon (`Page Monitor Pro`).
3. In **Refresh**:
   - Set **Mode** to `Interval`
   - Set **Interval (sec)** to `10` (example)
4. In **Monitor**:
   - Enable **page monitor**
   - Set **Monitor mode** to `Keyword appears`
   - Enter a keyword, for example: `in stock`
5. Click **Start**.

You should see:
- `Current tab status` -> **Running**
- `Next refresh` countdown
- Active tab shown in **Active tabs**

## 3) Refresh settings

### Interval mode
- Refreshes every fixed number of seconds.

### Random mode
- Refreshes between **Random Min** and **Random Max** each cycle.

### Countdown
- Initial delay before the first refresh starts.

### Refresh limit
- `0` = unlimited
- Any positive number = stop after that many refreshes.

### Hard refresh
- Reloads while bypassing cache.

### Stop on interaction
- Stops if you click, type, or interact with the page.

## 4) Monitor settings

### Monitor modes
- **Keyword appears**: triggers when keyword exists.
- **Keyword disappears**: triggers when keyword no longer exists.
- **Negative keyword appears**: triggers when any negative keyword is found.
- **Any page change**: triggers when page content hash changes.

### Expression types
- **Text**: simple contains match.
- **Regex**: regular expression.
- **XPath**: XPath expression against DOM.

### Source modes
- **Visible text**: uses page text (`innerText`).
- **HTML source**: uses page HTML (`outerHTML`).

### Auto-click selector
- Optional CSS selector to click automatically on match.
- Example: `.buy-now` or `button[type="submit"]`.

### Checkout action flow (assisted)
- Optional multi-step selector flow for product + cart + checkout clicks.
- Enter one CSS selector per line in popup:
  1. size/variant selector
  2. add-to-cart button
  3. cart/open-cart button
  4. checkout button
- Enable **Run checkout action flow on match** to trigger this automatically after monitor match.
- Or click **Assist checkout now** in popup to run the flow immediately.
- Set **Delay between action flow steps (ms)** if page/cart UI needs more time.

### MyNavyExchange quick setup
- Open any `mynavyexchange.com` product page.
- In popup click **Use MyNavyExchange preset**.
- Set **Preferred size** from dropdown (or choose **Custom**).
- Click **Start** to watch for stock + auto-run assist on match, or click **Assist checkout now**.
- The built-in MyNavyExchange assist uses site-specific fallback logic for:
  1. size selection
  2. add to cart
  3. open cart
  4. checkout

### Dropdown-first controls
- Use **Site profile** to target built-in flows.
- Use **Keyword preset** and **Negative keywords preset** instead of typing.
- Use **Checkout assist mode**:
  - `Site built-in flow (recommended)` for MyNavyExchange automation
  - `Custom selectors` only if you want manual CSS selector control

### Stop refreshing on match
- Stops refresh cycle when match occurs.

### Browser notification on match
- Shows local desktop notification.

## 5) Negative keywords (important)

Negative keywords are entered in popup as:
- comma-separated (`sold out, unavailable`)
- or newline-separated

Behavior:
- In **Keyword appears**, a match requires:
  1. Positive keyword found
  2. No negative keyword present
- In **Negative keyword appears**, any negative keyword triggers.

## 6) Current tab status and countdown

The popup includes a live status panel:
- **Running/Stopped** pill
- **Next refresh: Xs** countdown
- **Completed: N/limit**

If countdown is moving, monitoring is active.

## 7) Options page

Open from popup -> **Options** button.

### Auto-start URL rules
- One URL pattern per line.
- Supports `*` wildcard.
- Example: `https://example.com/products/*`

### Predefined URLs
- Store commonly monitored URLs (one per line).

### Default keyword and default negative keywords
- Pre-fills monitor values for new tabs/tasks.

## 8) Remote notifications (away from device)

Use this if you want alerts while away from your computer.

In **Options**:
1. Enable **Remote webhook notifications**
2. Paste your **Webhook URL**
3. Optional: add **Auth token** (Bearer token)
4. Set **Cooldown** to prevent spam
5. Save options

Common webhook targets:
- Discord webhook
- Slack webhook
- Zapier / Make webhook endpoints
- IFTTT / Pushover bridges

## 9) Sound notifications

In **Options**:
- Enable/disable sound
- Set volume
- Set repeat count
- Set tone frequency (Hz)
- Click **Test sound** to validate

Notes:
- Sound is played on the active webpage tab context.
- Keep a regular web page open when testing.

## 10) Keyboard shortcuts

Default commands:
- `Ctrl+Shift+Y` (`Cmd+Shift+Y` on Mac): start/stop current tab
- `Ctrl+Shift+U` (`Cmd+Shift+U` on Mac): stop all

You can customize shortcuts in Chrome:
- `chrome://extensions/shortcuts`

## 11) Troubleshooting

### Extension does not load
- Confirm folder contains `manifest.json`.
- Check `chrome://extensions` for error details.

### No refresh happening
- Confirm `Current tab status` is **Running**.
- Check interval is not too high.
- Avoid Chrome internal pages (`chrome://...`), they cannot be reloaded by extension scripts.

### Keyword match not triggering
- Switch source mode between **Visible text** and **HTML source**.
- Verify regex/xpath syntax if used.
- Check negative keywords are not suppressing positive mode.

### Remote notifications not arriving
- Recheck webhook URL.
- Lower cooldown to test.
- Verify endpoint accepts JSON POST.

### Sound test fails
- Keep an active normal tab open.
- Try interacting with the page, then test again.
- Ensure system/browser audio is not muted.

## 12) Recommended starting profile

For product stock tracking:
- Refresh: Interval `15s`
- Monitor mode: `Keyword appears`
- Keyword: `in stock`
- Negative keywords: `sold out`, `unavailable`
- Notify on match: On
- Remote notifications: On
- Sound notifications: On

---

If you want, this guide can be split into:
- a short one-page quick start
- and a separate advanced/admin guide.
