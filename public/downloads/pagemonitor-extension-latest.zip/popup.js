function $(id) {
  return document.getElementById(id);
}

function setStatus(text, isError = false) {
  const el = $("statusText");
  el.textContent = text;
  el.style.color = isError ? "#b91c1c" : "#065f46";
}

function parseNegativeKeywords(value) {
  return value
    .split(/\n|,/g)
    .map((item) => item.trim())
    .filter(Boolean);
}

function parseActionFlowSteps(value) {
  return value
    .split(/\n/g)
    .map((item) => item.trim())
    .filter(Boolean);
}

const KEYWORD_PRESETS = {
  add_to_cart: "add to cart",
  in_stock: "in stock",
  available_now: "available now"
};

const NEGATIVE_PRESETS = {
  sold_out_defaults: ["sold out", "out of stock", "unavailable", "not available"],
  none: []
};

function getKeywordPreset(keyword) {
  const normalized = String(keyword || "").trim().toLowerCase();
  for (const [preset, value] of Object.entries(KEYWORD_PRESETS)) {
    if (normalized === value) {
      return preset;
    }
  }
  return "custom";
}

function getNegativePreset(negativeKeywords = []) {
  const normalized = negativeKeywords.map((item) => String(item || "").trim().toLowerCase()).filter(Boolean);
  const defaults = NEGATIVE_PRESETS.sold_out_defaults;
  if (!normalized.length) {
    return "none";
  }
  if (defaults.every((value) => normalized.includes(value)) && normalized.length === defaults.length) {
    return "sold_out_defaults";
  }
  return "custom";
}

function getPreferredSizesFromControls() {
  const selected = $("preferredSize").value;
  if (selected === "auto") {
    return [];
  }
  if (selected === "custom") {
    const custom = $("preferredSizeCustom").value.trim();
    return custom ? [custom] : [];
  }
  return [selected];
}

function applyDynamicVisibility() {
  const showCustomKeyword = $("keywordPreset").value === "custom";
  const showCustomNegative = $("negativePreset").value === "custom";
  const showCustomFlow = $("assistMode").value === "custom_selectors";
  const showCustomSize = $("preferredSize").value === "custom";
  const showDebugOutput = $("debugEnabled").checked;
  $("keywordWrap").classList.toggle("hidden", !showCustomKeyword);
  $("negativeWrap").classList.toggle("hidden", !showCustomNegative);
  $("customFlowWrap").classList.toggle("hidden", !showCustomFlow);
  $("preferredSizeCustomWrap").classList.toggle("hidden", !showCustomSize);
  $("debugOutputWrap").classList.toggle("hidden", !showDebugOutput);
}

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function readForm() {
  const keywordPreset = $("keywordPreset").value;
  const negativePreset = $("negativePreset").value;
  const keyword =
    keywordPreset === "custom" ? $("keyword").value.trim() : KEYWORD_PRESETS[keywordPreset] || "";
  const negativeKeywords =
    negativePreset === "custom"
      ? parseNegativeKeywords($("negativeKeywords").value)
      : NEGATIVE_PRESETS[negativePreset] || [];

  return {
    refresh: {
      mode: $("refreshMode").value,
      intervalSec: toNumber($("intervalSec").value, 30),
      countdownSec: toNumber($("countdownSec").value, 0),
      randomMinSec: toNumber($("randomMinSec").value, 20),
      randomMaxSec: toNumber($("randomMaxSec").value, 40),
      limit: toNumber($("limit").value, 0),
      hardRefresh: $("hardRefresh").checked,
      showVisualTimer: $("showVisualTimer").checked,
      stopOnInteraction: $("stopOnInteraction").checked
    },
    monitor: {
      enabled: $("monitorEnabled").checked,
      siteProfile: $("siteProfile").value,
      assistMode: $("assistMode").value,
      keywordPreset,
      negativePreset,
      mode: $("monitorMode").value,
      expressionType: $("expressionType").value,
      source: $("source").value,
      keyword,
      negativeKeywords,
      debugEnabled: $("debugEnabled").checked,
      runActionFlowOnMatch: $("runActionFlowOnMatch").checked,
      actionFlowSteps:
        $("assistMode").value === "custom_selectors" ? parseActionFlowSteps($("actionFlowSteps").value) : [],
      preferredSizes: getPreferredSizesFromControls(),
      actionFlowStepDelayMs: toNumber($("actionFlowStepDelayMs").value, 1200),
      stopOnMatch: $("stopOnMatch").checked,
      notifyOnMatch: $("notifyOnMatch").checked
    }
  };
}

function fillForm(config) {
  const monitor = config.monitor || {};
  $("refreshMode").value = config.refresh.mode;
  $("intervalSec").value = config.refresh.intervalSec;
  $("countdownSec").value = config.refresh.countdownSec;
  $("randomMinSec").value = config.refresh.randomMinSec;
  $("randomMaxSec").value = config.refresh.randomMaxSec;
  $("limit").value = config.refresh.limit;
  $("hardRefresh").checked = Boolean(config.refresh.hardRefresh);
  $("showVisualTimer").checked = Boolean(config.refresh.showVisualTimer);
  $("stopOnInteraction").checked = Boolean(config.refresh.stopOnInteraction);

  $("monitorEnabled").checked = Boolean(monitor.enabled);
  $("siteProfile").value = monitor.siteProfile || "generic";
  $("assistMode").value = monitor.assistMode || "site_builtin";
  $("monitorMode").value = monitor.mode;
  $("expressionType").value = monitor.expressionType;
  $("source").value = monitor.source;
  $("keywordPreset").value = monitor.keywordPreset || getKeywordPreset(monitor.keyword || "");
  $("keyword").value = monitor.keyword || "";
  $("negativePreset").value =
    monitor.negativePreset || getNegativePreset(monitor.negativeKeywords || []);
  $("negativeKeywords").value = (monitor.negativeKeywords || []).join("\n");
  $("debugEnabled").checked = Boolean(monitor.debugEnabled);
  $("runActionFlowOnMatch").checked = Boolean(monitor.runActionFlowOnMatch);
  $("actionFlowSteps").value = (monitor.actionFlowSteps || []).join("\n");
  const preferredSize = (monitor.preferredSizes || [])[0] || "";
  const supportedSizes = new Set(
    Array.from($("preferredSize").options).map((item) => String(item.value))
  );
  if (!preferredSize) {
    $("preferredSize").value = "auto";
    $("preferredSizeCustom").value = "";
  } else if (supportedSizes.has(preferredSize)) {
    $("preferredSize").value = preferredSize;
    $("preferredSizeCustom").value = "";
  } else {
    $("preferredSize").value = "custom";
    $("preferredSizeCustom").value = preferredSize;
  }
  $("actionFlowStepDelayMs").value = Number(monitor.actionFlowStepDelayMs) || 1200;
  $("stopOnMatch").checked = Boolean(monitor.stopOnMatch);
  $("notifyOnMatch").checked = Boolean(monitor.notifyOnMatch);
  applyDynamicVisibility();
}

async function loadDebugTrace(tabId) {
  const response = await send("PM_GET_ASSIST_DEBUG", { tabId });
  $("debugOutput").value = (response?.debugTrace || []).join("\n");
}

function applyMyNavyExchangePreset() {
  $("monitorEnabled").checked = true;
  $("siteProfile").value = "mynavyexchange";
  $("assistMode").value = "site_builtin";
  $("monitorMode").value = "appears";
  $("expressionType").value = "text";
  $("source").value = "visible";
  $("keywordPreset").value = "add_to_cart";
  $("negativePreset").value = "sold_out_defaults";
  $("runActionFlowOnMatch").checked = true;
  $("actionFlowStepDelayMs").value = 1400;
  $("preferredSize").value = "14 M";
  $("preferredSizeCustom").value = "";
  $("actionFlowSteps").value = [
    ".product-size button:not([disabled])",
    ".size button:not([disabled])",
    "button[aria-label*='size' i]:not([disabled])",
    "button, input[type='submit']",
    "a[href*='/cart'], a[href*='cart'], button",
    "a[href*='checkout'], button, input[type='submit']"
  ].join("\n");
  applyDynamicVisibility();
}

async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

function formatTimeLeft(nextAt) {
  const diff = Math.max(0, nextAt - Date.now());
  const sec = Math.ceil(diff / 1000);
  return `${sec}s`;
}

let currentTabId = null;
let liveTickerId = null;

async function renderCurrentTabStatus() {
  if (!currentTabId) {
    return;
  }
  const response = await send("PM_GET_TAB_STATE", { tabId: currentTabId });
  const config = response.config;
  const runStateEl = $("runState");
  const countdownEl = $("liveCountdown");
  const countEl = $("liveCount");

  if (config.enabled) {
    runStateEl.textContent = "Running";
    runStateEl.className = "run-state running";
    const nextAt = Number(config.runtime?.nextAt) || 0;
    countdownEl.textContent =
      nextAt > 0 ? `Next refresh: ${formatTimeLeft(nextAt)}` : "Next refresh: scheduling...";
  } else {
    runStateEl.textContent = "Stopped";
    runStateEl.className = "run-state stopped";
    countdownEl.textContent = "Next refresh: --";
  }

  const completed = Number(config.runtime?.completed) || 0;
  const limit = Number(config.refresh?.limit) || 0;
  countEl.textContent = `Completed: ${completed}/${limit > 0 ? limit : "∞"}`;
}

async function renderActiveTabs() {
  const response = await send("PM_GET_ACTIVE_TABS");
  const list = $("activeTabs");
  list.innerHTML = "";
  const activeTabs = response.activeTabs || [];
  if (!activeTabs.length) {
    list.innerHTML = "<li>No active tabs</li>";
    return;
  }
  for (const item of activeTabs) {
    const li = document.createElement("li");
    const title = document.createElement("div");
    title.className = "title";
    title.textContent = item.title || item.url;
    const meta = document.createElement("div");
    meta.className = "meta";
    const limitLabel = item.limit > 0 ? `${item.completed}/${item.limit}` : `${item.completed}/∞`;
    meta.textContent = `Next: ${formatTimeLeft(item.nextAt)} | Count: ${limitLabel}`;
    li.appendChild(title);
    li.appendChild(meta);
    li.addEventListener("click", async () => {
      await chrome.tabs.update(item.tabId, { active: true });
      window.close();
    });
    list.appendChild(li);
  }
}

async function initialize() {
  const tab = await getCurrentTab();
  if (!tab?.id) {
    setStatus("No active tab", true);
    return;
  }
  currentTabId = tab.id;

  const state = await send("PM_GET_TAB_STATE", { tabId: tab.id });
  fillForm(state.config);
  await loadDebugTrace(tab.id);
  await renderActiveTabs();
  await renderCurrentTabStatus();

  if (liveTickerId) {
    clearInterval(liveTickerId);
  }
  liveTickerId = window.setInterval(async () => {
    await renderCurrentTabStatus();
    await renderActiveTabs();
  }, 1000);

  ["keywordPreset", "negativePreset", "assistMode", "preferredSize", "debugEnabled"].forEach((id) => {
    $(id).addEventListener("change", applyDynamicVisibility);
  });

  $("saveBtn").addEventListener("click", async () => {
    await send("PM_SAVE_TAB_CONFIG", { tabId: tab.id, config: readForm() });
    setStatus("Saved");
    await loadDebugTrace(tab.id);
    await renderActiveTabs();
    await renderCurrentTabStatus();
  });

  $("applyNexPresetBtn").addEventListener("click", async () => {
    if (!tab.url || !tab.url.includes("mynavyexchange.com")) {
      setStatus("Open a mynavyexchange.com page first", true);
      return;
    }
    applyMyNavyExchangePreset();
    await send("PM_SAVE_TAB_CONFIG", { tabId: tab.id, config: readForm() });
    setStatus("Applied MyNavyExchange preset");
    await loadDebugTrace(tab.id);
    await renderCurrentTabStatus();
  });

  $("startBtn").addEventListener("click", async () => {
    const config = readForm();
    await send("PM_START_TAB", { tabId: tab.id, config });
    setStatus("Started");
    await renderActiveTabs();
    await renderCurrentTabStatus();
  });

  $("runFlowBtn").addEventListener("click", async () => {
    const config = readForm();
    const response = await send("PM_RUN_ACTION_FLOW", {
      tabId: tab.id,
      monitor: config.monitor
    });
    $("debugOutput").value = (response?.debugTrace || []).join("\n");
    applyDynamicVisibility();
    if (response?.ok) {
      setStatus(`Checkout assist finished (${response.clicked}/${response.total})`);
    } else {
      setStatus(response?.error || "Checkout assist failed", true);
    }
    await renderActiveTabs();
    await renderCurrentTabStatus();
  });

  $("stopBtn").addEventListener("click", async () => {
    await send("PM_STOP_TAB", { tabId: tab.id });
    setStatus("Stopped");
    await loadDebugTrace(tab.id);
    await renderActiveTabs();
    await renderCurrentTabStatus();
  });

  $("stopAllBtn").addEventListener("click", async () => {
    await send("PM_STOP_ALL");
    setStatus("Stopped all tasks");
    await renderActiveTabs();
    await renderCurrentTabStatus();
  });

  $("openOptionsBtn").addEventListener("click", async () => {
    await chrome.runtime.openOptionsPage();
  });
}

window.addEventListener("unload", () => {
  if (liveTickerId) {
    clearInterval(liveTickerId);
    liveTickerId = null;
  }
});

initialize().catch((err) => setStatus(String(err?.message || err), true));
